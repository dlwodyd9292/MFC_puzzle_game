#pragma once

#include "MyImage.h"

CByteImage LoadImageFromDialog();
